<?php 
    session_start();
    
    if (!isset($_SESSION['username'])) {
        header("Location: login.php");
    }
?>

<!DOCTYPE html>
<html>
    <head>
        <link rel="stylesheet" type="text/css" href="css/main.css">
        <div class="banner">
            <div class="mandiribanner2">
                <img src="images/mandiri_kuning.png" alt="banner_index">
            </div>
            <div class="user_detail">
            <p></p>
            <?php 
                include 'config.php';
                
                $username = $_SESSION['username'];
                $sql = "SELECT * FROM user WHERE username='$username'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                // output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo $row["name"]."<br>";
                        echo "<br>";
                        echo $row["nip"]."<br>";
                        echo "<br>";
                    }
                } 
                else {
                    echo "0 results";
                }
                $conn->close();
 
            ?>
                <a href="logout.php" class="btn">Logout</a>
            </div>
        </div>
    </head>
    <body>
        <form action="" method="POST" class="form_index">
            <div class="form_div">
                <label class="label_index">
                    <span class="field">Kode Jabatan</span></br>
                    <br>
                    <input type="text" name="kode_jabatan" />
                </label>
                <label class="label_index">
                    <span class="field">Nama Jabatan</span></br>
                    <br>
                    <input type="text" name="nama_jabatan" />
                </label>
                <label class="label_index">
                    <span class="field">Level</span></br>
                    <br>
                    <select name="level" id="">
                        <option value=""></option>
                        <?php
                            include 'config.php';

                            $sql = "SELECT * FROM level";
                            $result = $conn->query($sql);

                            if($result->num_rows > 0) { ?>
                                <?php while ($row = $result->fetch_assoc()) { ?>
                                <option value=""><?php echo $row["nama_level"] ?></option>
                            <?php } ?>
                        <?php } ?>
                        </select>
                </label>
            </div>
            <div class="button_index">
                <input type="reset" id="clear" value="CLEAR">
                <button name="submit" id="login">SEARCH</button>
            </div>
        </form>
    </body>
    <footer>

    </footer>
</html>