<?php 
 
session_start();
 
if (!isset($_SESSION['username'])) {
    header("Location: index.php");
}
 
?>

<!DOCTYPE html>
<html>
    <head>
        
    </head>
    <body>
        <h1>Hello World</h1>
        <a href="logout.php" class"btn">Logout</a>
    </body>
    <footer>

    </footer>
</html>