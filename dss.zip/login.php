<?php 
 
include 'config.php';
 
    error_reporting(0);
    
    session_start();
    
    if (isset($_SESSION['username'])) {
        header("Location: index.php");
    }
    
    if (isset($_POST['submit'])) {
        $username = $_POST['username'];
        $password = $_POST['password'];
    
        $sql = "SELECT * FROM user WHERE username='$username' AND password='$password'";
        $result = mysqli_query($conn, $sql);
        if ($result->num_rows > 0) {
            $row = mysqli_fetch_assoc($result);
            $_SESSION['username'] = $row['username'];
            header("Location: index.php");
        } else {
            echo "<script>alert('Username atau password Anda salah. Silahkan coba lagi!')</script>";
        }
    }
 
?>

<!DOCTYPE HTML>
<html>
    <head>
        <title>Decision Support System</title>
        <meta name="viewport" content="width=device-width">
        <meta name="viewport" content="height=device-height">
        <link rel="stylesheet" type="text/css" href="css/main.css">
        <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    </head>
    <body>
        <div class="alert alert-warning" role="alert">
            <?php echo $_SESSION['error']?>
        </div>
        <div class="left-section">
            <div class="mandiribanner">
                <img src="images/mandiri.png" alt="banner">
            </div>
            <h1>Decision Support System</h1>
            <h1>Human Capital <br> Region VIII / Jawa 3</h1>
        </div>
        <div class="right-section">
            <form action="" method="POST">
                <h3>Login Page</h3>
                <h4>Username</h4>
                <input type="text" id="username" name="username"><br><br>
                <h4>Password</h4>
                <input type="password" id="password" name="password"><br><br>
                <input type="reset" id="clear" value="CLEAR">
                <button name="submit" id="login">SIGN IN</button>
            </form>
        </div>
    </body>
    <footer>
        
    </footer>
</html>